package com.pdm.boned;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MiSQLAdmin extends SQLiteOpenHelper {

    private static MiSQLAdmin sInstance;

    public static synchronized MiSQLAdmin getInstance(Context context){
        if(sInstance==null){
            sInstance=new MiSQLAdmin(context.getApplicationContext(),Constantes.BD_NAME,null,Constantes.BD_VERSION);
        }
        return sInstance;
    }
    public MiSQLAdmin(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+Constantes.TABLA+"(_id INTEGER primary key AUTOINCREMENT, socio TEXT, bonos INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+Constantes.TABLA);
        db.execSQL("CREATE TABLE "+Constantes.TABLA+"(_id INTEGER primary key AUTOINCREMENT, socio TEXT, bonos INTEGER)");
    }
}
