package com.pdm.boned02;

public class Item {
    String nombre;
    int id,bonos;

    public Item(String nombre, int id, int bonos) {
        this.nombre = nombre;
        this.id = id;
        this.bonos = bonos;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public int getBonos() {
        return bonos;
    }
}
