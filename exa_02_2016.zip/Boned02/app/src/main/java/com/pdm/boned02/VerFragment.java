package com.pdm.boned02;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Objects;

public class VerFragment extends Fragment {

    RecyclerView recyclerView;
    View view;
    private OnSocio mListener;


    public interface OnSocio{
        void onSocioClick(int id,String socio,int bonos);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnSocio) {
            mListener = (OnSocio) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public VerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_ver, container, false);
        ArrayList<Item> datos = leerDatos();
        recyclerView = view.findViewById(R.id.recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        MiAdaptador miAdaptador = new MiAdaptador(datos, getContext(), mListener);
        recyclerView.setAdapter(miAdaptador);
        return view;
    }

    private ArrayList<Item> leerDatos() {
        ArrayList<Item> datos = null;
        ContentResolver cr = Objects.requireNonNull(getContext()).getContentResolver();
        Uri nuestroURI = Constantes.CONTENT_URI;
        String[] projection = {
                Constantes.Column._ID,
                Constantes.Column.COL_SOC,
                Constantes.Column.COL_BON
        };
        Cursor cursor = cr.query(nuestroURI,
                projection,
                null,
                null,
                Constantes.Column.COL_SOC);
        if (cursor != null) {
            datos = new ArrayList<>(cursor.getCount());
            while (cursor.moveToNext()) {
                datos.add(new Item(cursor.getString(1),Integer.valueOf(cursor.getString(0)), Integer.valueOf(cursor.getString(2))));
            }
            cursor.close();
        }
        return datos;
    }
}
